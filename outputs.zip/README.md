
# Hyperparameter Tuning using GridSearchCV

## Dataset
Breast Cancer Dataset from sklearn

## Models Tuned
- Support Vector Machine
- Random Forest

## Method
- Train/Test Split
- GridSearchCV with 5-fold CV
- Compared default vs tuned models

## Outputs Saved
- Best Parameters JSON
- Performance CSV
- Confusion Matrix Images
- Classification Reports
- Saved Models

## Unique Approach
Dual-model tuning and automated artifact saving pipeline.
